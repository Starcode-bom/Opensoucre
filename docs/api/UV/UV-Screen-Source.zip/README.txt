UV Screen – sichtbare UV-Optik (kein echtes UV-Licht)

WINDOWS
- Datei: UV-Screen-Windows.exe
- Vollbild und immer im Vordergrund
- Violett: RGB(128, 0, 255)
- Versucht bei unterstützten internen Displays die Helligkeit auf 100 % zu setzen
- Beim Beenden wird die vorherige Helligkeit wiederhergestellt, soweit Windows/WMI sie lesen konnte
- ESC beendet die App

ANDROID
- Datei: UV-Screen-Android.apk
- Native Android-App ohne Internetzugriff und ohne angeforderte Berechtigungen
- Vollbild / immersive Anzeige
- Bildschirm bleibt an
- Fensterhelligkeit wird auf 1.0 (maximal) gesetzt
- Violett: RGB(128, 0, 255)
- Enthält ARM64, ARMv7, x86_64 und x86
- Paketname: com.starcode.uvscreen
- minSdk 21, targetSdk 28
- Lokal selbstsigniert

WICHTIG
Ein normaler LCD/OLED-Bildschirm kann kein echtes UV-Licht erzeugen. Die App zeigt nur sichtbares violettes/blaues Licht, das optisch ähnlich wirkt. Nicht längere Zeit aus kurzer Entfernung in einen Bildschirm mit maximaler Helligkeit starren.
