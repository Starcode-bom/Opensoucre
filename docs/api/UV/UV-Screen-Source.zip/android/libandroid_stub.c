typedef signed int int32_t; typedef unsigned int uint32_t; typedef struct ANativeActivity ANativeActivity; typedef struct ANativeWindow ANativeWindow; typedef struct ARect ARect; typedef struct ANativeWindow_Buffer ANativeWindow_Buffer;
void ANativeActivity_setWindowFlags(ANativeActivity*a,uint32_t b,uint32_t c){}
void ANativeActivity_setWindowFormat(ANativeActivity*a,int32_t b){}
int32_t ANativeWindow_setBuffersGeometry(ANativeWindow*a,int32_t b,int32_t c,int32_t d){return 0;}
int32_t ANativeWindow_lock(ANativeWindow*a,ANativeWindow_Buffer*b,ARect*c){return -1;}
int32_t ANativeWindow_unlockAndPost(ANativeWindow*a){return 0;}
