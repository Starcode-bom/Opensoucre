import struct, zlib, os

# Android binary XML constants
RES_XML_TYPE = 0x0003
RES_STRING_POOL_TYPE = 0x0001
RES_XML_RESOURCE_MAP_TYPE = 0x0180
RES_XML_START_NAMESPACE_TYPE = 0x0100
RES_XML_END_NAMESPACE_TYPE = 0x0101
RES_XML_START_ELEMENT_TYPE = 0x0102
RES_XML_END_ELEMENT_TYPE = 0x0103
UTF8_FLAG = 0x00000100
NO_INDEX = 0xFFFFFFFF
TYPE_STRING = 0x03
TYPE_INT_DEC = 0x10
TYPE_INT_BOOLEAN = 0x12

# Known android.R.attr IDs
ATTR_IDS = {
    'versionCode':       0x0101021b,
    'versionName':       0x0101021c,
    'minSdkVersion':     0x0101020c,
    'targetSdkVersion':  0x01010270,
    'label':             0x01010001,
    'name':              0x01010003,
    'hasCode':           0x0101000c,
    'exported':           0x01010010,
    'value':              0x01010024,
    'extractNativeLibs': 0x010104ea,
}

# Put framework attribute names first so the resource map is simple.
strings = [
    'versionCode','versionName','minSdkVersion','targetSdkVersion','label','name','hasCode','exported','value','extractNativeLibs',
    'android','http://schemas.android.com/apk/res/android',
    'manifest','package','com.starcode.uvscreen','1.0',
    'uses-sdk','application','UV Screen','false','true',
    'activity','android.app.NativeActivity','meta-data','android.app.lib_name','uvscreen',
    'intent-filter','action','android.intent.action.MAIN','category','android.intent.category.LAUNCHER'
]
idx = {s:i for i,s in enumerate(strings)}
ANDROID_NS = idx['http://schemas.android.com/apk/res/android']


def align4(b: bytes) -> bytes:
    return b + b'\x00' * ((-len(b)) & 3)


def len8(n):
    if n < 0x80:
        return bytes([n])
    return bytes([(n >> 8) | 0x80, n & 0xFF])


def string_pool():
    data = bytearray()
    offsets = []
    for s in strings:
        raw = s.encode('utf-8')
        offsets.append(len(data))
        data += len8(len(s))
        data += len8(len(raw))
        data += raw + b'\x00'
    data = bytearray(align4(bytes(data)))
    header_size = 28
    strings_start = header_size + 4 * len(strings)
    size = strings_start + len(data)
    out = bytearray()
    out += struct.pack('<HHI', RES_STRING_POOL_TYPE, header_size, size)
    out += struct.pack('<IIIII', len(strings), 0, UTF8_FLAG, strings_start, 0)
    out += b''.join(struct.pack('<I', o) for o in offsets)
    out += data
    return bytes(out)


def resource_map():
    ids = []
    for s in strings:
        ids.append(ATTR_IDS.get(s, 0))
    return struct.pack('<HHI', RES_XML_RESOURCE_MAP_TYPE, 8, 8 + 4*len(ids)) + b''.join(struct.pack('<I', x) for x in ids)


def node_header(t, size, line=1):
    return struct.pack('<HHIII', t, 16, size, line, NO_INDEX)


def start_ns():
    size = 24
    return node_header(RES_XML_START_NAMESPACE_TYPE, size) + struct.pack('<II', idx['android'], ANDROID_NS)


def end_ns():
    size = 24
    return node_header(RES_XML_END_NAMESPACE_TYPE, size) + struct.pack('<II', idx['android'], ANDROID_NS)


def attr(ns, name, raw=None, kind='string', value=None):
    ns_i = NO_INDEX if ns is None else ns
    name_i = idx[name]
    if kind == 'string':
        sval = raw if raw is not None else str(value)
        raw_i = idx[sval]
        data_type = TYPE_STRING
        data = idx[sval]
    elif kind == 'int':
        raw_i = NO_INDEX
        data_type = TYPE_INT_DEC
        data = int(value)
    elif kind == 'bool':
        raw_i = idx['true' if value else 'false']
        data_type = TYPE_INT_BOOLEAN
        data = 0xFFFFFFFF if value else 0
    else:
        raise ValueError(kind)
    # ResXMLTree_attribute = ns,name,rawValue + Res_value(size,res0,dataType,data)
    return struct.pack('<IIIHBBI', ns_i, name_i, raw_i, 8, 0, data_type, data)


def start_tag(name, attrs=None, line=1):
    attrs = attrs or []
    size = 16 + 20 + 20*len(attrs)
    out = bytearray(node_header(RES_XML_START_ELEMENT_TYPE, size, line))
    out += struct.pack('<IIHHHHHH', NO_INDEX, idx[name], 20, 20, len(attrs), 0, 0, 0)
    for a in attrs:
        out += a
    return bytes(out)


def end_tag(name, line=1):
    size = 24
    return node_header(RES_XML_END_ELEMENT_TYPE, size, line) + struct.pack('<II', NO_INDEX, idx[name])

chunks = []
chunks.append(string_pool())
chunks.append(resource_map())
chunks.append(start_ns())
chunks.append(start_tag('manifest', [
    attr(ANDROID_NS,'versionCode',kind='int',value=1),
    attr(ANDROID_NS,'versionName',raw='1.0'),
    attr(None,'package',raw='com.starcode.uvscreen'),
], 2))
chunks.append(start_tag('uses-sdk', [
    attr(ANDROID_NS,'minSdkVersion',kind='int',value=21),
    attr(ANDROID_NS,'targetSdkVersion',kind='int',value=28),
], 3))
chunks.append(end_tag('uses-sdk', 3))
chunks.append(start_tag('application', [
    attr(ANDROID_NS,'label',raw='UV Screen'),
    attr(ANDROID_NS,'hasCode',kind='bool',value=False),
    attr(ANDROID_NS,'extractNativeLibs',kind='bool',value=True),
], 4))
chunks.append(start_tag('activity', [
    attr(ANDROID_NS,'name',raw='android.app.NativeActivity'),
    attr(ANDROID_NS,'exported',kind='bool',value=True),
], 5))
chunks.append(start_tag('meta-data', [
    attr(ANDROID_NS,'name',raw='android.app.lib_name'),
    attr(ANDROID_NS,'value',raw='uvscreen'),
], 6))
chunks.append(end_tag('meta-data',6))
chunks.append(start_tag('intent-filter', [], 7))
chunks.append(start_tag('action', [attr(ANDROID_NS,'name',raw='android.intent.action.MAIN')], 8))
chunks.append(end_tag('action',8))
chunks.append(start_tag('category', [attr(ANDROID_NS,'name',raw='android.intent.category.LAUNCHER')], 9))
chunks.append(end_tag('category',9))
chunks.append(end_tag('intent-filter',10))
chunks.append(end_tag('activity',11))
chunks.append(end_tag('application',12))
chunks.append(end_tag('manifest',13))
chunks.append(end_ns())
body = b''.join(chunks)
out = struct.pack('<HHI', RES_XML_TYPE, 8, 8+len(body)) + body
path='/mnt/data/uv-screen/android/apk/AndroidManifest.xml'
with open(path,'wb') as f: f.write(out)
print(path, len(out), hex(zlib.adler32(out)&0xffffffff))
