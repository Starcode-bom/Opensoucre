typedef signed int int32_t;
typedef unsigned int uint32_t;
typedef unsigned long size_t;

typedef struct ANativeActivity ANativeActivity;
typedef struct ANativeWindow ANativeWindow;
typedef struct AInputQueue AInputQueue;
typedef struct AAssetManager AAssetManager;
typedef struct JavaVM JavaVM;
typedef void* JNIEnv;
typedef void* jobject;
typedef void* jclass;
typedef void* jmethodID;
typedef void* jfieldID;

typedef struct ARect { int32_t left, top, right, bottom; } ARect;

typedef struct ANativeWindow_Buffer {
    int32_t width;
    int32_t height;
    int32_t stride;
    int32_t format;
    void* bits;
    uint32_t reserved[6];
} ANativeWindow_Buffer;

typedef struct ANativeActivityCallbacks {
    void (*onStart)(ANativeActivity* activity);
    void (*onResume)(ANativeActivity* activity);
    void* (*onSaveInstanceState)(ANativeActivity* activity, size_t* outSize);
    void (*onPause)(ANativeActivity* activity);
    void (*onStop)(ANativeActivity* activity);
    void (*onDestroy)(ANativeActivity* activity);
    void (*onWindowFocusChanged)(ANativeActivity* activity, int hasFocus);
    void (*onNativeWindowCreated)(ANativeActivity* activity, ANativeWindow* window);
    void (*onNativeWindowResized)(ANativeActivity* activity, ANativeWindow* window);
    void (*onNativeWindowRedrawNeeded)(ANativeActivity* activity, ANativeWindow* window);
    void (*onNativeWindowDestroyed)(ANativeActivity* activity, ANativeWindow* window);
    void (*onInputQueueCreated)(ANativeActivity* activity, AInputQueue* queue);
    void (*onInputQueueDestroyed)(ANativeActivity* activity, AInputQueue* queue);
    void (*onContentRectChanged)(ANativeActivity* activity, const ARect* rect);
    void (*onConfigurationChanged)(ANativeActivity* activity);
    void (*onLowMemory)(ANativeActivity* activity);
} ANativeActivityCallbacks;

struct ANativeActivity {
    ANativeActivityCallbacks* callbacks;
    JavaVM* vm;
    JNIEnv* env;
    jobject clazz;
    const char* internalDataPath;
    const char* externalDataPath;
    int32_t sdkVersion;
    void* instance;
    AAssetManager* assetManager;
    const char* obbPath;
};

extern void ANativeActivity_setWindowFlags(ANativeActivity* activity, uint32_t addFlags, uint32_t removeFlags);
extern void ANativeActivity_setWindowFormat(ANativeActivity* activity, int32_t format);
extern int32_t ANativeWindow_setBuffersGeometry(ANativeWindow* window, int32_t width, int32_t height, int32_t format);
extern int32_t ANativeWindow_lock(ANativeWindow* window, ANativeWindow_Buffer* outBuffer, ARect* inOutDirtyBounds);
extern int32_t ANativeWindow_unlockAndPost(ANativeWindow* window);

#define AWINDOW_FLAG_KEEP_SCREEN_ON 0x00000080u
#define AWINDOW_FLAG_FULLSCREEN     0x00000400u
#define WINDOW_FORMAT_RGBA_8888 1

/* JNI function-table slots are standardized by the JNI specification. */
static void apply_java_window_settings(ANativeActivity* activity) {
    if (!activity || !activity->env || !activity->clazz) return;
    void** env = (void**)activity->env;
    void** f = (void**)(*env);
    if (!f) return;

    typedef jclass (*GetObjectClassFn)(void**, jobject);
    typedef jmethodID (*GetMethodIDFn)(void**, jclass, const char*, const char*);
    typedef jobject (*CallObjectMethodFn)(void**, jobject, jmethodID, ...);
    typedef void (*CallVoidMethodFn)(void**, jobject, jmethodID, ...);
    typedef jfieldID (*GetFieldIDFn)(void**, jclass, const char*, const char*);
    typedef void (*SetFloatFieldFn)(void**, jobject, jfieldID, float);

    GetObjectClassFn GetObjectClass = (GetObjectClassFn)f[31];
    GetMethodIDFn GetMethodID = (GetMethodIDFn)f[33];
    CallObjectMethodFn CallObjectMethod = (CallObjectMethodFn)f[34];
    CallVoidMethodFn CallVoidMethod = (CallVoidMethodFn)f[61];
    GetFieldIDFn GetFieldID = (GetFieldIDFn)f[94];
    SetFloatFieldFn SetFloatField = (SetFloatFieldFn)f[111];

    jclass activityClass = GetObjectClass(env, activity->clazz);
    if (!activityClass) return;
    jmethodID midGetWindow = GetMethodID(env, activityClass, "getWindow", "()Landroid/view/Window;");
    if (!midGetWindow) return;
    jobject window = CallObjectMethod(env, activity->clazz, midGetWindow);
    if (!window) return;

    jclass windowClass = GetObjectClass(env, window);
    if (!windowClass) return;

    /* Window-local brightness: 1.0 = maximum, without changing global settings. */
    jmethodID midGetAttrs = GetMethodID(env, windowClass, "getAttributes", "()Landroid/view/WindowManager$LayoutParams;");
    jmethodID midSetAttrs = GetMethodID(env, windowClass, "setAttributes", "(Landroid/view/WindowManager$LayoutParams;)V");
    if (midGetAttrs && midSetAttrs) {
        jobject attrs = CallObjectMethod(env, window, midGetAttrs);
        if (attrs) {
            jclass attrsClass = GetObjectClass(env, attrs);
            if (attrsClass) {
                jfieldID fidBrightness = GetFieldID(env, attrsClass, "screenBrightness", "F");
                if (fidBrightness) {
                    SetFloatField(env, attrs, fidBrightness, 1.0f);
                    CallVoidMethod(env, window, midSetAttrs, attrs);
                }
            }
        }
    }

    /* Immersive sticky UI: hide navigation + status bars. */
    jmethodID midDecor = GetMethodID(env, windowClass, "getDecorView", "()Landroid/view/View;");
    if (midDecor) {
        jobject decor = CallObjectMethod(env, window, midDecor);
        if (decor) {
            jclass viewClass = GetObjectClass(env, decor);
            if (viewClass) {
                jmethodID midUi = GetMethodID(env, viewClass, "setSystemUiVisibility", "(I)V");
                if (midUi) CallVoidMethod(env, decor, midUi, 5894);
            }
        }
    }
}

static void on_focus_changed(ANativeActivity* activity, int hasFocus) {
    if (hasFocus) apply_java_window_settings(activity);
}

static void draw_uv(ANativeWindow* window) {
    if (!window) return;
    ANativeWindow_setBuffersGeometry(window, 0, 0, WINDOW_FORMAT_RGBA_8888);
    ANativeWindow_Buffer b;
    if (ANativeWindow_lock(window, &b, (ARect*)0) != 0 || !b.bits) return;

    uint32_t* p = (uint32_t*)b.bits;
    /* RGBA bytes: R=128, G=0, B=255, A=255 => little-endian 0xFFFF0080 */
    const uint32_t uv = 0xFFFF0080u;
    for (int32_t y = 0; y < b.height; ++y) {
        uint32_t* row = p + (size_t)y * (size_t)b.stride;
        for (int32_t x = 0; x < b.width; ++x) row[x] = uv;
    }
    ANativeWindow_unlockAndPost(window);
}

static void on_window_created(ANativeActivity* activity, ANativeWindow* window) {
    (void)activity;
    draw_uv(window);
}

static void on_window_resized(ANativeActivity* activity, ANativeWindow* window) {
    (void)activity;
    draw_uv(window);
}

static void on_window_redraw(ANativeActivity* activity, ANativeWindow* window) {
    (void)activity;
    draw_uv(window);
}

__attribute__((visibility("default")))
void ANativeActivity_onCreate(ANativeActivity* activity, void* savedState, size_t savedStateSize) {
    (void)savedState;
    (void)savedStateSize;
    ANativeActivity_setWindowFormat(activity, WINDOW_FORMAT_RGBA_8888);
    ANativeActivity_setWindowFlags(activity, AWINDOW_FLAG_KEEP_SCREEN_ON | AWINDOW_FLAG_FULLSCREEN, 0);
    apply_java_window_settings(activity);
    activity->callbacks->onWindowFocusChanged = on_focus_changed;
    activity->callbacks->onNativeWindowCreated = on_window_created;
    activity->callbacks->onNativeWindowResized = on_window_resized;
    activity->callbacks->onNativeWindowRedrawNeeded = on_window_redraw;
}
