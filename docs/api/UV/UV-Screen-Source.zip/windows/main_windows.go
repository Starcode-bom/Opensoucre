//go:build windows

package main

import (
    "fmt"
    "os/exec"
    "strconv"
    "strings"
    "syscall"
    "unsafe"
)

const (
    CS_HREDRAW       = 0x0002
    CS_VREDRAW       = 0x0001
    WS_POPUP         = 0x80000000
    WS_EX_TOPMOST    = 0x00000008
    SW_SHOW          = 5
    WM_DESTROY       = 0x0002
    WM_KEYDOWN       = 0x0100
    VK_ESCAPE        = 0x1B
    SM_CXSCREEN      = 0
    SM_CYSCREEN      = 1
    SWP_SHOWWINDOW   = 0x0040
    ES_CONTINUOUS    = 0x80000000
    ES_DISPLAY_REQUIRED = 0x00000002
)

type POINT struct {
    X int32
    Y int32
}

type MSG struct {
    Hwnd    uintptr
    Message uint32
    WParam  uintptr
    LParam  uintptr
    Time    uint32
    Pt      POINT
}

type WNDCLASSEX struct {
    CbSize        uint32
    Style         uint32
    LpfnWndProc   uintptr
    CbClsExtra    int32
    CbWndExtra    int32
    HInstance     uintptr
    HIcon         uintptr
    HCursor       uintptr
    HbrBackground uintptr
    LpszMenuName  *uint16
    LpszClassName *uint16
    HIconSm       uintptr
}

var (
    user32                  = syscall.NewLazyDLL("user32.dll")
    kernel32                = syscall.NewLazyDLL("kernel32.dll")
    gdi32                   = syscall.NewLazyDLL("gdi32.dll")
    procRegisterClassExW    = user32.NewProc("RegisterClassExW")
    procCreateWindowExW     = user32.NewProc("CreateWindowExW")
    procDefWindowProcW      = user32.NewProc("DefWindowProcW")
    procShowWindow          = user32.NewProc("ShowWindow")
    procUpdateWindow        = user32.NewProc("UpdateWindow")
    procGetMessageW         = user32.NewProc("GetMessageW")
    procTranslateMessage    = user32.NewProc("TranslateMessage")
    procDispatchMessageW    = user32.NewProc("DispatchMessageW")
    procPostQuitMessage     = user32.NewProc("PostQuitMessage")
    procDestroyWindow       = user32.NewProc("DestroyWindow")
    procGetSystemMetrics    = user32.NewProc("GetSystemMetrics")
    procSetWindowPos        = user32.NewProc("SetWindowPos")
    procShowCursor          = user32.NewProc("ShowCursor")
    procSetProcessDPIAware  = user32.NewProc("SetProcessDPIAware")
    procCreateSolidBrush    = gdi32.NewProc("CreateSolidBrush")
    procGetModuleHandleW    = kernel32.NewProc("GetModuleHandleW")
    procSetThreadExecutionState = kernel32.NewProc("SetThreadExecutionState")
)

var oldBrightness = -1

func rgb(r, g, b byte) uintptr {
    return uintptr(uint32(r) | uint32(g)<<8 | uint32(b)<<16)
}

func currentBrightness() int {
    cmd := exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command",
        "(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty CurrentBrightness)")
    out, err := cmd.Output()
    if err != nil {
        return -1
    }
    s := strings.TrimSpace(string(out))
    v, err := strconv.Atoi(s)
    if err != nil || v < 0 || v > 100 {
        return -1
    }
    return v
}

func setBrightness(v int) {
    ps := fmt.Sprintf("Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods -ErrorAction SilentlyContinue | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName WmiSetBrightness -Arguments @{Timeout=1;Brightness=%d} | Out-Null }", v)
    _ = exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", ps).Run()
}

func wndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
    switch msg {
    case WM_KEYDOWN:
        if wParam == VK_ESCAPE {
            procDestroyWindow.Call(hwnd)
            return 0
        }
    case WM_DESTROY:
        for {
            r, _, _ := procShowCursor.Call(1)
            if int32(r) >= 0 {
                break
            }
        }
        procSetThreadExecutionState.Call(ES_CONTINUOUS)
        if oldBrightness >= 0 {
            setBrightness(oldBrightness)
        }
        procPostQuitMessage.Call(0)
        return 0
    }
    ret, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
    return ret
}

func main() {
    procSetProcessDPIAware.Call()
    procSetThreadExecutionState.Call(ES_CONTINUOUS | ES_DISPLAY_REQUIRED)

    oldBrightness = currentBrightness()
    go setBrightness(100)

    hInstance, _, _ := procGetModuleHandleW.Call(0)
    className, _ := syscall.UTF16PtrFromString("UVScreenClass")
    title, _ := syscall.UTF16PtrFromString("UV Screen")

    brush, _, _ := procCreateSolidBrush.Call(rgb(128, 0, 255))

    wc := WNDCLASSEX{
        CbSize:        uint32(unsafe.Sizeof(WNDCLASSEX{})),
        Style:         CS_HREDRAW | CS_VREDRAW,
        LpfnWndProc:   syscall.NewCallback(wndProc),
        HInstance:     hInstance,
        HbrBackground: brush,
        LpszClassName: className,
    }

    atom, _, _ := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
    if atom == 0 {
        return
    }

    width, _, _ := procGetSystemMetrics.Call(SM_CXSCREEN)
    height, _, _ := procGetSystemMetrics.Call(SM_CYSCREEN)

    hwnd, _, _ := procCreateWindowExW.Call(
        WS_EX_TOPMOST,
        uintptr(unsafe.Pointer(className)),
        uintptr(unsafe.Pointer(title)),
        WS_POPUP,
        0, 0, width, height,
        0, 0, hInstance, 0,
    )
    if hwnd == 0 {
        return
    }

    procSetWindowPos.Call(hwnd, ^uintptr(0), 0, 0, width, height, SWP_SHOWWINDOW)
    procShowWindow.Call(hwnd, SW_SHOW)
    procUpdateWindow.Call(hwnd)
    for {
        r, _, _ := procShowCursor.Call(0)
        if int32(r) < 0 {
            break
        }
    }

    var msg MSG
    for {
        r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
        if int32(r) <= 0 {
            break
        }
        procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
        procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
    }
}
