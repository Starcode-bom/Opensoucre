module uvscreen

go 1.23
